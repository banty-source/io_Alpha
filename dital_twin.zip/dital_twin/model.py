import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

# Load datasets
pipe_data = pd.read_csv('pipe.csv')
consumption_data = pd.read_csv('consumption.csv')
reservoir_data = pd.read_csv('reservoir.csv')
station_data = pd.read_csv('station.csv')
water_quality_data = pd.read_csv('water_quality.csv')
city_data = pd.read_csv('city.csv')  # New dataset

# Water Quality Prediction (Classification Task)
X_quality = water_quality_data.iloc[:, :-1].values
y_quality = water_quality_data.iloc[:, -1].values
X_train, X_test, y_train, y_test = train_test_split(X_quality, y_quality, test_size=0.2, random_state=42)
rf_classifier = RandomForestClassifier()
rf_classifier.fit(X_train, y_train)
y_pred_quality = rf_classifier.predict(X_test)
print("Water Quality Prediction Accuracy:", accuracy_score(y_test, y_pred_quality))

# Shortest Distance Prediction (Regression Task)
X_distance = station_data.iloc[:, :-1].values  # Assuming station data contains location info
y_distance = pipe_data['distance'].values  # Distance from pipe dataset
X_train, X_test, y_train, y_test = train_test_split(X_distance, y_distance, test_size=0.2, random_state=42)
lr_regressor = LinearRegression()
lr_regressor.fit(X_train, y_train)
y_pred_distance = lr_regressor.predict(X_test)
print("Predicted Shortest Distances:", y_pred_distance)

# Water Occupied in Pipe Prediction (Regression Task)
X_water_occupied = pipe_data[['pipe_diameter', 'pipe_length']].values
y_water_occupied = pipe_data['water_occupied'].values
X_train, X_test, y_train, y_test = train_test_split(X_water_occupied, y_water_occupied, test_size=0.2, random_state=42)
dt_regressor = DecisionTreeRegressor()
dt_regressor.fit(X_train, y_train)
y_pred_occupied = dt_regressor.predict(X_test)
print("Predicted Water Occupied in Pipe:", y_pred_occupied)

# Water Supply Coverage Prediction (Classification Task)
X_coverage = station_data[['station_location', 'pipe_length']].values
y_coverage = station_data['covers_all_houses'].values  # Assuming this column exists
X_train, X_test, y_train, y_test = train_test_split(X_coverage, y_coverage, test_size=0.2, random_state=42)
knn_classifier = KNeighborsClassifier(n_neighbors=5)
knn_classifier.fit(X_train, y_train)
y_pred_coverage = knn_classifier.predict(X_test)
print("Water Supply Coverage Prediction Accuracy:", accuracy_score(y_test, y_pred_coverage))

# Water Demand Prediction (Regression Task)
X_demand = city_data[['population_density', 'avg_consumption_per_household']].values
y_demand = consumption_data['total_consumption'].values  # Assuming this column exists
X_train, X_test, y_train, y_test = train_test_split(X_demand, y_demand, test_size=0.2, random_state=42)
demand_regressor = LinearRegression()
demand_regressor.fit(X_train, y_train)
y_pred_demand = demand_regressor.predict(X_test)
print("Predicted Water Demand:", y_pred_demand)

# Water Shortage Prediction (Classification Task)
X_shortage = consumption_data[['consumption_rate', 'reservoir_capacity']].values
y_shortage = consumption_data['shortage'].values  # Assuming this column exists
X_train, X_test, y_train, y_test = train_test_split(X_shortage, y_shortage, test_size=0.2, random_state=42)
svm_classifier = SVC(kernel='linear')
svm_classifier.fit(X_train, y_train)
y_pred_shortage = svm_classifier.predict(X_test)
print("Water Shortage Prediction Accuracy:", accuracy_score(y_test, y_pred_shortage))

# Leakage Detection (Anomaly Detection Task)
X_leakage = pipe_data[['pipe_length', 'water_flow_rate']].values
iso_forest = IsolationForest(contamination=0.1)
iso_forest.fit(X_leakage)
leakage_pred = iso_forest.predict(X_leakage)
print("Leakage Detection (1: Normal, -1: Anomaly):", leakage_pred)
